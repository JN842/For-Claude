# ZQ raw data snapshot — 3 November 2026

This archive contains the project's 152 raw 1-minute Fed Funds futures (ZQ) Parquet contract files from raw/. SOFR files in raw/sofr/ are excluded.

Contents:
- raw/ZQ..._1m.parquet: original price files, unchanged
- metadata/zq_raw_audit.parquet: audit of the raw batch
- metadata/zq_time_basis.parquet: evidence for the TradingView Asia/Bangkok price clock
- metadata/event_contract_map.parquet: macro event to M1/M3/M6 contract mapping
- metadata/event_contract_map_rejections.parquet: mapping rejections
- metadata/README.md: description of the metadata tables
- manifest.csv: byte lengths and SHA-256 checksums of each Parquet file

The raw timestamp column is naive on disk. Read metadata/zq_time_basis.parquet and validate it against the raw audit before converting timestamps; do not assume UTC. Contract mapping is separate from raw prices.
