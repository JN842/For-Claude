# ZQ metadata tables

## Price-time evidence

`data/metadata/zq_time_basis.parquet` is an ignored, one-row-per-raw-batch
evidence table. For the current source it records the user-supplied TradingView
chart setting (`Asia/Bangkok`) together with the audited ZQ contract-hash
summary and a CME-session DST fingerprint. It does not modify a raw price
Parquet or make its naive timestamp column timezone-aware on disk.

| column | meaning |
| --- | --- |
| `raw_dataset_id` | Stable batch key: `tradingview_zq_asia_bangkok_v1` |
| `raw_directory` | Project-relative raw location, currently `raw` |
| `platform`, `symbol_family` | `TradingView`, `ZQ` |
| `price_timezone` | Evidenced IANA price clock: `Asia/Bangkok` |
| `timezone_status` | `evidenced_chart_setting` |
| `evidence_type`, `evidence_notes` | Reason and supporting session-fingerprint observation |
| `verified_at_utc`, `reference_urls` | Verification time and external provenance |
| `audit_sha256_summary` | Digest that binds the record to `zq_raw_audit.parquet` |

Run `notebooks/05_zq_raw_audit.ipynb` and then
`notebooks/06_zq_time_basis_and_asof.ipynb`. A future analysis must load this
record against the current audit table before it localizes raw timestamps or
converts a macro release instant to the price clock.

The order of responsibility is:

```text
raw ZQ prices -> zq_raw_audit -> zq_time_basis -> macro_events -> event_contract_map
```

## Event-to-contract map

Notebook 08 writes `data/metadata/event_contract_map.parquet` separately
from `raw/`. It contains one row per macro event that has all three mapped
contracts in the current valid ZQ audit.

| column | meaning |
| --- | --- |
| `event_id` | Stable unique event identifier, for example `CPI_202609` |
| `event_type`, `reference_period` | Canonical macro-event context copied from `macro_events` |
| `event_time_utc` | Source release instant, preserved as aware UTC |
| `event_time` | The same instant converted to the evidenced `Asia/Bangkok` price clock |
| `price_timezone` | The mapped price clock, currently `Asia/Bangkok` |
| `m1_contract` | ZQ contract one calendar month after the event month |
| `m3_contract` | ZQ contract three calendar months after the event month |
| `m6_contract` | ZQ contract six calendar months after the event month |

For `2026-09-11 08:30 Asia/Bangkok`, the expected contracts are
`ZQV2026`, `ZQZ2026`, and `ZQH2027`. The map is calculated from the
macro release UTC instant, then filtered against the current raw audit; it is
not embedded into individual price Parquet files.

`data/metadata/event_contract_map_rejections.parquet` has one row per macro
event excluded because one or more mapped contract files are absent or have an
invalid schema. Its `missing_contracts` and `rejection_reason` columns make
the coverage boundary explicit instead of silently loading a partial curve.

Run `notebooks/08_zq_event_contract_map.ipynb` after Notebooks 05, 06, and
07. It validates the current audit digest against the time-basis evidence,
writes both map tables, and demonstrates a raw M1/M3/M6 price window in
`Asia/Bangkok`. It does not calculate a repricing return.

## Macro events

Notebook 07 creates these ignored, local-only artifacts in data/metadata/.

| file | grain and purpose |
| --- | --- |
| macro_events.parquet | One row per eligible release group. It supplies stable event_id, raw Investing time, release_time_et, release_time_utc, and release_time_bangkok. |
| macro_event_values.parquet | One row per published series; it links many values such as headline/Core CPI to macro_events.event_id. |
| macro_event_build_rejections.parquet | Source rows not used in the first event universe, with out_of_scope, unparseable_timestamp, inconsistent_reference_period, or duplicate_series_key reasons. |

The source is an immutable Investing CSV snapshot under data/raw/investing/<sha256>/. The committed BLS/BEA/Census sample table validates the timestamp interpretation but is not fetched during routine builds. All canonical records label previous_pit_status as unproven_current_snapshot.

Individual source rows are sometimes stamped at the wrong time: a single row an hour early splits a release in two, and one whole release is an hour late. `metadata/macro_event_time_corrections.csv` lists each such row by asset digest and row number, with the corrected label and the official BLS/BEA release time that proves it. The builder applies it before grouping, refuses a correction that does not match the row it names, and lists the corrections behind an event in `time_correction_ids`. It also refuses any release outside its family's official Eastern slot (08:30, or 10:00 for JOLTS and for personal income when BEA pairs it with GDP), so a new defect in a refreshed source stops the build instead of passing silently. `scripts/rebuild_macro_events_from_snapshot.py` rebuilds the three tables from the saved snapshot without downloading anything and reports what changed.
A trailing (MoM), (QoQ) or (YoY) is part of the series name, not a reference period, so a release whose YoY row omits the month is kept; a release that really mixes two months (the post-shutdown PCE releases of 2019-03-01, 2019-03-29 and 2019-04-29) is still rejected as inconsistent_reference_period.



## Derived Fed repricing events

Notebook 09 writes the ignored local-only
`data/derived/fed_repricing_events.parquet`. It is a long table at
event-by-tenor grain, preserving the exact pre/post targets, selected
timestamps, close prices, staleness, and selection statuses.

| fields | meaning |
| --- | --- |
| `event_id`, `event_type`, `reference_period`, `event_time` | Macro-event provenance and evidenced Bangkok price-clock instant |
| `contract_horizon`, `contract` | The M1/M3/M6 curve tenor and raw ZQ file declared by the map |
| `pre_target_time`, `post_target_time` | Fixed targets: one minute before and 30 minutes after the release |
| `pre_selected_timestamp`, `post_selected_timestamp`, `*_staleness_minutes` | Selected as-of price evidence |
| `pre_close`, `post_close`, `price_change` | Raw ZQ price movement |
| `implied_rate_change_bps` | `(pre_close - post_close) * 100`; positive means implied rate rose |
| `repricing_status` | `selected` only when both prices satisfy the five-minute staleness policy; otherwise explicit pre/post availability states |

The output is an auditable mechanical window calculation, not a causal estimate
or trading recommendation. It never changes a raw price table.

## Meeting-specific binary probabilities

Notebook 25 adds a separate, conditional probability layer. It must not be
confused with the M1/M3/M6 repricing output above: it selects the ZQ delivery
month that contains the **next regular FOMC decision** for each macro release.

`data/metadata/effr_daily_nyfed.json` is an immutable local snapshot from the
Federal Reserve Bank of New York public EFFR endpoint. Its normalized companion
`effr_daily_nyfed.csv` supplies the latest completed business-day EFFR before a
release, so the probability calculation does not use a release-day fixing.

Each selected scenario explicitly assumes only two outcomes at the next
meeting: hold versus a 25 bp hike (`hike_25bp`), or hold versus a 25 bp cut
(`cut_25bp`). The policy move takes effect on the calendar day after the FOMC
decision. A meeting-month ZQ price outside the corresponding 0%–100% binary
range is retained with `outside_binary_bounds`; it is not clipped.

The notebook writes these ignored local artifacts:

| file | grain and purpose |
| --- | --- |
| `data/derived/fomc_probability_event_inputs.parquet` | one macro release, next-FOMC contract/day-count and prior EFFR |
| `data/derived/fomc_probability_price_pairs.parquet` | one macro release, exact ZQ pre/post selection evidence |
| `data/derived/fomc_probability_events.parquet` | one release × named binary scenario, including probability status and 50% crossing class |
| `data/derived/fomc_probability_asset_study.parquet` | selected scenario × ES/GOLD reaction windows and ES cash-open fields |

The resulting 50% crossing labels are a descriptive diagnostic. They must be
compared with non-crossing moves of similar probability size before being used
as a trading input.

## FedWatch-style probability table

Notebook 26 turns the meeting-month ZQ price pairs into a long table with one
`pre` and one `post` row per macro release. It reports `p_cut_pct`,
`p_hold_pct`, and `p_hike_pct`, together with the implied monthly EFFR and the
expected meeting move in basis points.

This is a conditional, one-direction 25 bp model rather than the official CME
FedWatch distribution: a single ZQ contract identifies one expected monthly
EFFR, so a valid row is hold versus one cut or hold versus one hike. Missing
prices and prices implying more than one step remain visible through
`fedwatch_status` and are not clipped.

The notebook writes `data/derived/fedwatch_probability_table.parquet`,
`data/derived/fedwatch_probability_table.csv`, and the interactive
`reports/fedwatch_probability_table.html`.
## Continuous ZQ repricing study

Notebook 27 keeps the meeting-month ZQ signal continuous instead of turning it
into coarse probabilities. It computes the pre/post change in the expected
next-meeting move (`zq_repricing_bps`; positive means implied Fed rate up) and
joins one row per event and asset to the ES/GOLD event-window reactions.

The output preserves only events with both ZQ observations selected under the
five-minute as-of rule. It writes
`data/derived/continuous_zq_repricing_asset_study.parquet`,
`data/derived/continuous_zq_repricing_summary.parquet`, and the interactive
`reports/continuous_zq_repricing_study.html`.
## PyFedWatch-style multi-meeting distributions

Notebook 28 adapts the public `pyfedwatch` method to the local ZQ exports. It
uses multiple monthly contracts around each FOMC month, reconstructs
`Pstart/Pend`, splits each meeting into adjacent 25 bp states, and convolves
those states across up to nine upcoming meetings.

The output is a long event × meeting × outcome table in
`data/derived/pyfedwatch_historical_table.parquet` and `.csv`, with the
interactive `reports/pyfedwatch_historical.html`. The table keeps missing
boundary prices and events with no future meetings explicit through
`probability_status`.

This is a method reproduction using local TradingView prices, not an official
CME historical FedWatch snapshot. Price sparsity and the local target-range
metadata remain part of the audit boundary.
## PyFedWatch wide probability matrix

Notebook 29 adds the wide view used in the upstream example: FOMC meetings are
rows, target-rate ranges are columns, and cells are percentage probabilities
with a blue intensity gradient. It writes a static example matrix near the
2023-03-10 watch date and an event-selectable interactive matrix report:
`reports/pyfedwatch_matrix_latest.html` and
`reports/pyfedwatch_probability_matrix.html`.

## FOMC meeting calendar and cancelled meetings

`data/metadata/fomc_meeting_dates.csv` lists the scheduled regular FOMC
decisions (14:00 ET on the second day); every engine uses it to decide which
meetings are still ahead. `metadata/fomc_meeting_cancellations.csv` records
scheduled meetings that were cancelled and the instant they stopped being
upcoming. The only one since 2015 is 2020-03-18 (the Fed's own 2020 page lists
"March 17-18 (cancelled)"): policy was set instead at the unscheduled meetings
of 3 Mar and 15 Mar, whose rate changes are in `fomc_policy_actions.csv`.

`macro_calendar.pyfedwatch_method.load_meeting_calendar` merges the two files.
A cancelled meeting stays an FOMC month for the start/end chain, so unscheduled
moves inside that month never leak into the next meeting's start price, but from
its cancellation instant it is no longer an upcoming meeting. Until the row was
added in 2020-09 the calendar had no March 2020 meeting and every release from
2020-01-30 to 2020-04-29 saw the wrong "next meeting" (releases after 17 Mar
showed a false ~55 bp cut at the April meeting). `tests/test_fomc_calendar.py`
guards eight regular meetings per year and the row format.

## Local-engine intraday tables

`scripts/build_local_intraday_monitor.py` runs
`macro_calendar.pyfedwatch_intraday` on every macro release at -5, 0, +1, +5 and
+30 minutes and writes `data/derived/local_intraday_{probabilities,status,rate_paths,event_summary}.parquet`
plus the easy-to-read `reports/fed_repricing_monitor.html`. It checks that every
snapshot lists the next uncancelled meetings in order.

`scripts/build_intraday_fed_repricing_mvp.py` and
`scripts/build_cpi_pre_release_feature_panel.py` read those tables by default
(`--source local`) and produce the same columns as before. `--source package`
reads the upstream `pyfedwatch` tables instead (run
`scripts/build_pyfedwatch_intraday.py` first so they match the calendar). The
MVP records its source in `data/derived/intraday_fed_repricing_source.json`, and
the panel refuses a repricing table built from the other engine. Staleness is
defined differently: the local `path_max_staleness_minutes` counts only live
(unexpired) contracts, the package one also counts expired contracts.